# GEANE, VALÉRIA, RAIMUNDA, KASSYANE - 4º PERÍDO DE LIC.COMPUTAÇÃO

import sqlite3
import sys
from PyQt6.QtWidgets import  QApplication, QWidget
from PyQt6 import uic
from cliente_form import Ui_cliente
from sqlite3 import Error as e

class Cliente_main(QWidget):
    def __init__(self):
        super().__init__()
        self.ui =uic.loadUi('cliente_form.ui',self)
        self.ui.bt_inserir.clicked.connect(self.inserir_cliente)
        #self.ui.bt_foto.clicked.connect(self.inserir_foto)

        self.ui.bt_foto.clicked.connect(self.inserir_cliente)
        self.ui.bt_buscar.clicked.connect(self.buscar)
        self.ui.bt_editar.clicked.connect(self.editar)
        self.show()

    def inserir_cliente(self):
        nome = self.ui.lineEdit_nome.text()
        foto = self.ui.lineEdit_foto.text()
        cpf = self.ui.lineEdit_cpf.text()
        msg = "Cliente cadastrado com sucesso!"
        try:
            con = sqlite3.connect('lojapoo.sqlite3')
            cursor = con.cursor()
            cursor.execute("""
            INSERT INTO cliente(nome_cliente, foto_cliente, cpf_cliente)VALUES (?,?,?)""",
                           (nome, foto, cpf))
            con.commit()
            self.ui.label_msg.setText(msg + " " + nome)
            con.close()
            self.limpar()
        except e:
            self.ui.label_msg.setText(e)

    #def inserir_foto(self):
        #try:
            #file_path,_= QFileDialog.getOpenFileName(self,"Selecioanar Foto","",
           # "Imagens(*.jpg.png*.jpeg*.bmp;;Todos os Arquivos()")
                #in file_path:
                    #pixmap = QPixmap(file_path)
                    #self.lb_foto.setPixmap(pixmap)
                    #self.lb_foto.setScaledContents(True)
                    #self.add_foto = file_path
        #except Exception as e:
            #print(f'Erro na seleção da imagem: {str(e)}')
            #self.ui.label_msg.setText(e)


    def limpar(self):
        self.ui.lineEdit_nome.setText("")
        self.ui.lineEdit_foto.setText("")
        self.ui.lineEdit_cpf.setText("")


    def buscar(self):
        busca = self.ui.lineEdit_buscar.text()
        try:
            con = sqlite3.connect('lojapoo.sqlite3')
            cursor =con.cursor()
            cursor.execute("""
            SELECT * FROM cliente WHERE id_cliente ==?
            """,(busca))
            b= cursor.fetchone()
            if b is not None:
                self.ui.lineEdit_nome.setText(b[1])
                self.ui.lineEdit_cpf.setText(b[2])
        except e:
            self.ui.label_msg.setText(e)


    def editar(self):
        cod = self.ui.lineEdit_buscar.text()
        nome = self.ui.lineEdit_nome.text()
        foto = self.ui.lineEdit_foto_foto.text()
        cpf = self.ui.lineEdit_cpf.text()
        try:
            con = sqlite3.connect('lojapoo.sqlite3')
            cursor = con.cursor()
            cursor.execute("""
            UPDATE cliente SET
            nome_cliente =?,
            foto_cliente =?,
            cpf_cliente =?
            WHERE
            id_cliente ==?
            """, (nome,foto,cpf, int(cod)))
            con.commit()
            con.close()
        except e:
            self.ui.label_msg(e)




if __name__=='__main__':
    janela = QApplication(sys.argv)
    app = Cliente_main()
    sys.exit(janela.exec())

