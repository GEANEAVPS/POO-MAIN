import sqlite3
from sqlite3 import Error as e
class Cliente:
    def __init__(self, id, nome, foto, cpf):
        self.id = id
        self.nome = nome
        self.foto = foto
        self.cpf = cpf

    def cad_cliente(self):
        try:
            conn = sqlite3.connect('lojapoo.sqlite3')
            cursor = conn.cursor()
            self.nome = input('Digite o nome do cliente: ')
            self.foto = input('Insira a foto do cliente: ')
            self.cpf = input('Informe o CPF do cliente: ')

            cursor.execute("""INSERT INTO cliente (nome,foto, cpf) VALUES (?,?,?)
            """, (self.nome, self.foto, self.cpf))
            conn.commit()
            conn.close()
        except e:
            print(e)


    def mostrar_cliente(self):
        try:
            conn = sqlite3.connect('lojapoo.sqlite3')
            cursor = conn.cursor()
            cursor.execute("""SELECT * FROM cliente""")
            for cliente in cursor:
                print(cliente)
        except e:
            print(e)


    def mostrar_id(self):
        try:
            conn = sqlite3.connect('lojapoo.sqlite3')
            cursor = conn.cursor()
            self.id =input('Pesquisa o Id do cliente: ')
            cursor.execute("""SELECT * FROM cliente WHERE id=?""",(self.id))
            print(cursor.fetchone())
        except e:
            print(e)


    def mostrar_nome(self):
        try:
            conn = sqlite3.connect('lojapoo.sqlite3')
            cursor = conn.cursor()
            self.nome =input('Pesquisa o Nome do cliente:')
            cursor.execute("""SELECT * FROM cliente WHERE nome=?""",(self.nome))
            print(cursor.fetchall())
            conn.commit()
            conn.close()
        except e:
            print(e)


    def deletar_id(self):
        try:
            conn = sqlite3.connect('lojapoo.sqlite3')
            cursor = conn.cursor()
            self.id =input('Delete o Cliente com Id: ')
            cursor.execute("""DELETE FROM cliente WHERE id=?""",(self.id,))
            conn.commit()
            conn.close()
        except e:
            print(e)


    def editar_id(self):
        try:
            conn = sqlite3.connect('lojapoo.sqlite3')
            cursor = conn.cursor()
            self.id =input('Editar o Cliente com Id: ')
            self.nome = input("Novo nome do Cliente:")
            self.foto = input("Nova foto")
            self.cpf = input("Novo CPF")
            cursor.execute("""UPDATE cliente
            SET nome =?,foto =?,cpf=?, 
            WHERE id=?""",(self.nome,self.foto, self.cpf))
            conn.commit()
            conn.close()
        except e:
            print(e)

